jQuery(function ($){

  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    items: 1,
    autoplay:true
})

});
